#One-replication document includes 1 R code:
    #BnB_Gaussian.R outputs the Nodewise L0BnB estimator and the running time under Gaussian design under one replication  
      and saves the result.      

#Combine document includes 1 R code that combine the results under 100 replications based on the preserved Rdata using code in One-
  replication document.

